#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <time.h>

double get_random(double lowBd, double upBd);

double compFunction(int funct, double x);

double compIntegral(int funct, double x);
