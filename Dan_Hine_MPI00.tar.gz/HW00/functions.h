#include <mpi.h>
#include <stdio.h>
#include <math.h>

void global_sum(double* result, int rank, int size, double my_value);
